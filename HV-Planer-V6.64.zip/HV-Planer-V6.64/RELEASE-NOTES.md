# Release Notes – V6.64

## Ruhigerer Stromlaufplan

- 1P- und 3P-Leitungsschutzschalter stehen jetzt auf derselben Höhe.
- Die 3P-Zuführungen und Abgänge wurden optisch an die gemeinsame Gerätehöhe angepasst.
- Keine Änderung an der elektrischen Logik oder den gespeicherten Projektdaten.


- Rückgängig/Wiederholen mit Buttons sowie Strg+Z / Strg+Y.
- Strg+D dupliziert die aktuelle Auswahl; Duplikate starten ohne kopierte Verdrahtung.
- Bestand/Neu-Status pro Gerät; Neu wird grün markiert.
- Einfügestatus in der Kopfleiste und Stücklistenfilter „nur Neu“.
- Visuelle Snap-Linie beim Verschieben auf der Hutschiene.
- Neuer Plausibilitätscheck für offene/ungültige Modellstellen; ausdrücklich keine Normprüfung.

# V6.62

- Neue integrierte **Hilfe / Anleitung** direkt im HV-Planer.
- Ausführliche `ANLEITUNG.md` im Programmordner ergänzt.
- Schnellreferenz beschreibt Planung, Zoom, Stromschienen, Verdrahtung, Auswertungen, Speichern/Laden und Bestandsaufnahme.
- Veraltete Versionsanzeigen in About und Footer auf V6.62 korrigiert.

# V6.61

- Kleiner **100-%-Reset** direkt neben der Ansichts-Skalierung.
- Ein Klick setzt die Planansicht sofort auf 100 %, ohne Projektgeometrie oder Gerätepositionen zu verändern.
- Besonders praktisch nach Detailarbeit bei 200–250 % Zoom.
- Sonst keine Änderungen an Planung, Verdrahtung oder Stromlaufplanlogik.

# V6.60

- Neuer Schalter **„Zur Auswahl springen“** in der Kopfzeile.
- Ist der Schalter deaktiviert, bleibt die aktuelle Bildschirmposition beim Setzen, Verschieben oder Auswählen von Geräten erhalten.
- Ideal bei hoher Ansichts-Skalierung, wenn mehrere Elemente nacheinander platziert werden sollen.
- Einstellung wird in der Projektdatei gespeichert; ältere Projekte starten wie bisher mit aktiviertem Sprung.

# HV-Planer V6.59 – Release Notes

## Neu in V6.59
- Ansichtsgröße bis **250 %** erweitert.
- Skalierung weiterhin in **5-%-Schritten** von 60 bis 250 %.
- Die Erweiterung betrifft ausschließlich die Darstellung; TE/mm, Gerätepositionen und Verdrahtungslogik bleiben unverändert.


- Die grafische Stromschiene / Leiterfolge sitzt jetzt **unterhalb der Geräte**. Damit entspricht die Darstellung besser der realen Anordnung einer Phasenschiene unter den Schutzgeräten.
- Die globale Option **„Leiterfolge anzeigen“** wurde entfernt. Ob und welche Stromschiene vorhanden ist, wird ausschließlich pro Reihe über **Keine / 1-phasig / 3-phasig** festgelegt.
- Reihen ohne Stromschiene behalten weiterhin denselben reservierten Darstellungsraum, damit alle Reihen und Felder exakt ausgerichtet bleiben.
- Gespeicherte ältere Projekte bleiben kompatibel; ein eventuell vorhandener alter `showPhaseRail`-Wert wird beim Laden schlicht ignoriert.
- Keine Änderung an Phasen-, RCD-, N-/PE- oder Verdrahtungslogik.

## V6.57 – Einheitliche Felder & skalierbare Planansicht

- Alle Felder mit gleicher Konfiguration werden jetzt unabhängig von ihrer Belegung gleich groß dargestellt.
- Auch Reihen ohne Stromschiene reservieren bei eingeblendeter Leiterfolge denselben Darstellungsraum wie belegte Reihen; dadurch bleiben die Reihen feldübergreifend exakt ausgerichtet.
- Neue **Ansichtsgröße** in der Konfiguration: 60–140 % in 5-%-Schritten.
- Die Skalierung wirkt gemeinsam auf alle Felder und verändert ausschließlich die Darstellung – TE, mm, Gerätepositionen und logische Verdrahtung bleiben unverändert.
- Die Ansichtsgröße wird in der Projektdatei gespeichert und beim Laden wiederhergestellt; ältere Projekte starten bei 100 %.
- Klick- und Drag-Positionierung berücksichtigt die gewählte Skalierung weiterhin maßgenau.

## V6.56 – Plan laden wieder sichtbar

- Der Button **„Plan laden“** war seit längerem weiß auf weiß beschriftet.
- Ursache war die vom dunklen Kopfbereich geerbte weiße Textfarbe des Datei-Labels.
- Die Dateiauswahl hat jetzt dieselbe dunkle Beschriftung wie die übrigen Aktionsbuttons.
- Keine Änderung an Plan-, Verdrahtungs- oder Stromlaufplanlogik.

# HV-Planer V6.55

- Stromlaufplan-Fläche ist bei großen RCD-Gruppen nicht mehr auf die bisherige Grundbreite begrenzt.
- Die benötigte Breite wird dynamisch aus Anzahl und Typ der dargestellten Stromkreis-Spalten berechnet.
- 3-polige Zweige werden mit ihrer größeren Darstellungsbreite korrekt berücksichtigt.
- Umfangreiche Verteilungen wachsen horizontal mit und können im Dialog gescrollt werden, statt rechts abgeschnitten zu werden.
- Keine Änderung an Verdrahtungs-, RCD-, N-/PE- oder Stromschienenlogik.

# HV-Planer V6.54

- Stromlaufplan leiterweise nachgeschärft: L, N und PE werden jetzt getrennt geführt.
- Außenleiter laufen über den LS direkt in das L-Segment der L/N/PE-Reihenklemme.
- Neutralleiter kommen separat vom N-Ausgang des zugehörigen RCD und enden im N-Segment.
- PE erhält eine durchgehende horizontale Potentiallinie und separate senkrechte Abgänge in das PE-Segment.
- Beim 3-poligen LS bleiben L1/L2/L3 vollständig gerade; Symbol und Anschlussachsen wurden auf die drei L-Segmente der Zielklemmen ausgerichtet.
- Keine Änderung an der logischen Zuordnung, RCD-Gruppenlogik oder Stromschienenlogik.

# HV-Planer V6.53

## 3P-Stromlaufplan fachgerecht begradigt

- Der 3-polige LS wird im Stromlaufplan jetzt bewusst breit dargestellt.
- L1, L2 und L3 liegen auf festen, durchgehenden Anschlussachsen.
- Die drei Leiter laufen vor und nach dem LS gerade senkrecht; keine seitlichen Versätze oder Zickzack-Pfade mehr.
- Die drei Pole des LS-Symbols sind direkt auf die drei nachgeordneten Klemmen ausgerichtet.
- Logische Verdrahtung, RCD-/N-Zuordnung und Stromschienenlogik bleiben unverändert.

# HV-Planer V6.53

## 3P-LS im Stromlaufplan sauber als gemeinsame Einheit

- L1, L2 und L3 verlassen den 3-poligen LS jetzt direkt an den drei Polpositionen des Schaltzeichens.
- Die drei Leiter laufen zunächst parallel aus dem Gerät heraus und werden erst darunter zu den drei Zielklemmen aufgefächert.
- Damit entsteht kein optischer Eindruck mehr, L2 oder L3 würden seitlich bzw. als eigener Strompfad aus dem LS herausgeführt.
- Die Zielpositionen der Reihenklemmen beeinflussen weiterhin nicht die Anschlusspositionen am Schutzgerät.
- Logische Verdrahtung, RCD-/N-Zuordnung und Stromschienenlogik bleiben unverändert.
